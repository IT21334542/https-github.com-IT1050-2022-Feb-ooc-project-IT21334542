#pragma once
class Payment
{
protected:
    char id[10];
    float total;
    float discount;
    float Last_tot;
public:
    void display();
};
//Cash.h
class Cash : public Payment {
protected:
    float amount;
    float balance;
public:
    Cash();
    void display();
};
//Credit.h
class Credit : public Payment {
protected:
    char Card_type[20];
    char Card_num[20];
    char Exp_date[5];

public:
    Credit();
    void display();
};
