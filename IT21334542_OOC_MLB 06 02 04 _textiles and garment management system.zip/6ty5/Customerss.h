
#pragma once
class Customers
{
protected:
	string Name;
	string Address;
	string Mail;
	string P_NUmber;
public:
	Customers();
	Customers(string name, string addr, string mail, string number);
	void setname(string name);
	void setaddress(string add);
	void setmail(string mail);
	void setPhonenumber(string number);
	string getname();
	string getmail();
	string getaddress();
	string getPhoneNumber();
	virtual	void displayBasicdetails() = 0;
};
