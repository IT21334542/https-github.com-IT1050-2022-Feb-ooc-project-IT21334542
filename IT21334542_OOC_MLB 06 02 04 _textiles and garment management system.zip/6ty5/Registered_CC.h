#pragma once
#include"Customerss.h"
class Registered_C :public Customers
{
private:
	string reg_id;
	string password;
public:
	Registered_C();
	Registered_C(string name, string addr, string mail, string passwordd, string idr, string numberP)
		:Customers(name, addr, mail, numberP), reg_id(idr), password(passwordd) {}
	void setregistrationId(string id);
	void setPassword(string pass);
	void displayBasicdetails();
	void displaypassword();
};
