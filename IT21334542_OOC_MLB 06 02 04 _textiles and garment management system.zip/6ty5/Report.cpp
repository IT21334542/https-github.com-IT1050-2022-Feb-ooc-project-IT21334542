#include"Report.h"

Report::Report() {
	quantity = 0;
	price = 0.0;
}
Report::Report(int Qty, float Price) {
	quantity = Qty;
	price = Price;
}