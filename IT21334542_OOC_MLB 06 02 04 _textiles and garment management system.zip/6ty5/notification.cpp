#include"notification.h"

void notification::sendNotification(string pnotificationIDD, string pdatee, string pcontentt) {
	notificationID = pnotificationIDD;
	date = pdatee;
	content=pcontentt;
};

string notification::getNotification() {
	return content;
};