#include"cart.h"
Cart::Cart(string	pCartID)
{
    CartID = pCartID;
    quantity = 0;
}
void Cart::addOutfit(Outfit* O)
{
    if (quantity < SIZE)
        outfit[quantity] = O;
    quantity++;
}
void Cart::displayCart()
{
    cout << " Cart ID : " << CartID << endl;
    cout << " Quantity : " << quantity << endl;
    for (int i = 0; i < quantity; i++)
        outfit[i]->displayOut();
}