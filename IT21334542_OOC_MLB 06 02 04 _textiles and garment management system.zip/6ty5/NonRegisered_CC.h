#pragma once
#include"Customerss.h"
class NonRegisered_C :public Customers
{
private:
	string id;
public:
	NonRegisered_C();
	NonRegisered_C(string name, string addr, string mail, string idn, string numberP)
		:Customers(name, addr, mail, numberP), id(idn)
	{}
	void displayBasicdetails();

};
