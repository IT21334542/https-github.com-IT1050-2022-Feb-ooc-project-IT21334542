#include "NonRegisered_CC.h"
void NonRegisered_C::displayBasicdetails()
{
	cout << "Customer ID::\t" << id << endl << "NAME::\t\t" << Name << endl << "Address::\t" << Address << endl << "Mail::\t\t" << Mail << endl << "Phone Number::\t" << P_NUmber << endl << endl;
}