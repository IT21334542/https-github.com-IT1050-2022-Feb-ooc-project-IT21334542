// 6ty5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<cstring>
using namespace std;
#include"Customerss.h"
#include"Registered_CC.h"
#include"NonRegisered_CC.h"
#include"Payment.h"
#include "email.h"
#include"notification.h"
#include"SMS.h"
#include "Report.h"
#include"Inquiry.h"
#include"cart.h"
#include"outfit.h"


int main()
{
	Registered_C Rone("kamal", "jaffna", "shankarjeev@mail.com", "jeevanu12", "R001", "0776920616");
	NonRegisered_C NCone("Ravan", "Colombo", "ravan0080@gmail.com", "NC001", "0112505406");

	Customers* one;
	one = &Rone;
	one->displayBasicdetails();
	cout << "\n\n\n\nNON REGISTERED>>>>>>>>>>>>>>>>\n\n\n";
	one = &NCone;
	one->displayBasicdetails();


	Credit Cr1;
	Cash C1;

	Cr1.display();
	cout << endl;

	C1.display();

	Inquiry I1("Ravi", "ravi@gmail.com", 7745453);
	Report r1(11, 2000);
	I1.DisplayInquiry();

	char ch;
	Cart* C1 = new Cart("123");
	Cart* C2 = new Cart("456");
	Outfit* O1 = new Outfit("001", 3450, C1);
	Outfit* O2 = new Outfit("002", 8500, C2);
	cout << "orders of" << endl;
	C1.display();
	cin >> ch;


	string pnotificationIDD = "001";

	notification not1;
	not1.sendNotification("001", "2020_05_01", "Newsfeed");	
	
	cout << not1.getNotification();

	return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
