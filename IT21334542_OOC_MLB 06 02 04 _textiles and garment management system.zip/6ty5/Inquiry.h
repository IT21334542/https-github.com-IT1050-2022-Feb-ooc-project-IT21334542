#pragma once
#include<iostream>
using namespace std;



class Inquiry {
private:
	string inqu;
	string Email;
	int PhoneNumber;


public:
	Inquiry();
	Inquiry(string inquiryy, string email, int phoneNo);
	void DisplayInquiry();

};