#include "Inquiry.h"

Inquiry::Inquiry()
{
	inqu = "";
	Email = "";
	PhoneNumber = 0;
}

Inquiry::Inquiry(string inquiryy, string email, int phoneNo) {
	inqu = inquiryy;
	Email = email;
	PhoneNumber = phoneNo;
}

void Inquiry::DisplayInquiry() {}

#include "Inquiry.h"
