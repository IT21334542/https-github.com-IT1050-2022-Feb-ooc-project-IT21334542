#pragma once
#include <iostream>
using namespace std;
class email
{
private:
    string email[100];

public:
    void setemail(string pemail);

};
