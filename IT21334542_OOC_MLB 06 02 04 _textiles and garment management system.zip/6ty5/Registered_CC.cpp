#include "Registered_CC.h"
void Registered_C::displayBasicdetails()
{
	cout << "Registration ID::" << reg_id << endl << "NAME::\t\t" << Name << endl << "Address::\t" << Address << endl << "Mail::\t\t" << Mail << endl << "Phone Number::\t" << P_NUmber << endl << endl;
}

void Registered_C::displaypassword()
{
	cout << "Current Password is ::" << password;
}
void Registered_C::setregistrationId(string id)
{
	reg_id = id;
}

void Registered_C::setPassword(string pass)
{
	password = pass;
}
