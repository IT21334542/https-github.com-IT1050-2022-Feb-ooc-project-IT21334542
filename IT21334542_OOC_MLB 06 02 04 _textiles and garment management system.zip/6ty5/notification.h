#pragma once
#include <iostream>
#include <String>
#include "email.h"
#include "SMS.h"

using namespace std;

class notification
{
private:
    string notificationID;
    string date;
    string content;

public:
    notification();
    void sendNotification(string pnotificationIDD, string pdatee, string pcontentt);
    string getNotification();
};
