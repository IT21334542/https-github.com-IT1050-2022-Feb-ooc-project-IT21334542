
#include "email.h"

void email::setemail(pemail) {
	strcpy(pemail, email);
};
