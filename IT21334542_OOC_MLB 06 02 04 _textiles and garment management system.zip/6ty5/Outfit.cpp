#include "Outfit.h"
Outfit::Outfit(string pOutfitID, float pPrice, Cart * pCar)
{
    OutfitID = pOutfitID;
    price = pPrice;
    Car = pCar;
    Car->addOutfit(this);
}
void Outfit::displayOut()
{
    cout << " OutfitID : " << OutfitID << endl;
    cout << " price : " << price << endl;

}
