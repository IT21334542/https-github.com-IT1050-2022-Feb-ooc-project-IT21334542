#pragma once

class Cart;
class outfits;

class Outfit
{
private:
    string OutfitID;
    float price;
    Cart* Car;
public:
    Outfit(string pOutfitID, float pPrice, Cart& pCar);
    void displayOut();
};


class Cart
{
private:


    string CartID;
    Outfit* outfits[SIZE];
    int quantity;


public:

    Cart(string	pCartID);
    void addOutfit(Outfit* O);
    void displayCart();
};