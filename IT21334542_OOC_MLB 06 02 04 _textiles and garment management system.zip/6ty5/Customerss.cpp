#include "Customerss.h"

Customers::Customers(string name, string addr, string mail, string number) {
	Name = name;
	Address = addr;
	Mail = mail;
	P_NUmber = number;
}

void Customers::setname(string name)
{
	Name = name;
}

void Customers::setmail(string mail)
{
	Mail = mail;
}

void Customers::setaddress(string add)
{
	Address = add;
}

void Customers::setPhonenumber(string number)
{
	P_NUmber = number;
}

string Customers::getname()
{
	return Name;
}


string Customers::getmail()
{
	return Mail;
}
string Customers::getaddress()
{
	return Address;
}
string Customers::getPhoneNumber()
{
	return P_NUmber;
}