#include "Payment.h"
#include <iostream>

using namespace std;

void Payment::display() {
    cout << "Total After the discount : " << Last_tot << endl;
}
//Cash.cpp
Cash::Cash() {
    strcpy_s(id, "002");
    total = 3500;
    discount = 300;
    amount = 5000;
    balance = 1800;
    Last_tot = 3200;
}
void Cash::display() {
    cout << "Payment ID : " << id << endl;
    cout << "Total Bill : " << total << endl;
    cout << "Total Discount : " << discount << endl;
    cout << "Cash amount : " << amount << endl;
    cout << "Given Balance : " << balance << endl;
    Payment::display();
}
//Credit.cpp
Credit::Credit() {
    strcpy_s(id, "001");
    total = 2500;
    discount = 250;
    strcpy_s(Card_type, "Visa");
    strcpy_s(Card_num, "25666458979465456");
    strcpy_s(Exp_date, "0228");
    Last_tot = 2250;
}
void Credit::display() {
    cout << "Payment ID : " << id << endl;
    cout << "Total Bill : " << total << endl;
    cout << "Total Discount : " << discount << endl;
    cout << "Card type : " << Card_type << endl;
    cout << "Card number : " << Card_num << endl;
    cout << "Expiry date : " << Exp_date << endl;
    Payment::display();
}
