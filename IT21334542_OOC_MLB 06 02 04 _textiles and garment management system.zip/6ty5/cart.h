#pragma once
#include <iostream> 
#include <string>
#define SIZE 10
using namespace std;




class Cart
{
private:

    
    string CartID; 
    Outfit* outfits[SIZE];
    int quantity;


public:

    Cart(string	pCartID);
    void addOutfit(Outfit* O);
    void displayCart();
};



